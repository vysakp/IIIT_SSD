select CONCAT(Fname,' ',Minit,' ',Lname) as Fullname, Ssn, Dno from EMPLOYEE group by Ssn;
