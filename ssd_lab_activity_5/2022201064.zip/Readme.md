Contents
-> index.HTML -- Main page HTML file
-> studentsRecords.HTML -- Student record HTML file 
-> style.css  -- CSS file 