                README

#####q1.sh##### 
Shell script to find the middle line of the give file.
File : Input file is expected to be given as argument

Execution 
./q1.sh <file_path>

#####q2.sh#####
Shell script to find all the shells present in /etc/shells
that starts with /usr/

Execution 
./q2.sh